'''import matplotlib.pyplot as plt
x=['A','B','C','D']
y1=[10,20,10,30]
y2=[20,25,15,25]
plt.bar(x, y1,color='g')
plt.bar(x, y2,bottom=y1, color='b')
plt.show()'''

'''
import matplotlib.pyplot as plt
import numpy as np
x=['A','B','C','D']
y1=np.array([10,20,10,30])
y2=np.array([20,25,15,25])
y3=np.array([12,15,19,6])
y4=np.array([10,29,13,19])
plt.bar(x, y1,color='g')
plt.bar(x, y2,bottom=y1, color='b')
plt.bar(x, y3,bottom=y1+y2, color='y')
plt.bar(x, y4,bottom=y1+y2+y3, color='g')
plt.xlabel("teams")
plt.ylabel("score")
plt.legend(["round 1","round 2","round 3","round 4"])
plt.title("scores by team in 4 rounds")
plt.show()'''

'''
print("max of 54,32,3.93,49,100 is :  ", end="")
print(max(54,32,3.93,49,100))

print("min of 54,32,3.93,49,100 is :  ", end="")
print(min(54,32,3.93,49,100))'''

