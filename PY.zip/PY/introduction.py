'''print("First Program - Python print function")
print("It is declared like this:")
print("print ('What to print')")'''

'''print("hello world\nhello world\nhello world")'''

'''print("Hello"+" "+"Sarthak")'''

'''print("String Manipulation Exercise\nString Concatination is done with + sign\ne.g. print(""Hello +" + "Sarthak"")\nNew lines can be created with a backslash and n")'''

from unicodedata import name
from pkg_resources import safe_extra


#input("What is your name?\n")
'''print("Hello" + " " + input("What is your name? "), input("How are you?") )'''

'''name="sarthak"
print(name)'''

'''name=input("What is your name ?")
length=len(name)
print(length)'''

a=input("enter value of a ")
b=input("enter value of b ")
c=a
a=b
b=c
print("a= "+a)
print("b= "+b)